import { useState } from "react";
import { Link } from "react-router";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  LayoutDashboard,
  Users,
  ShieldCheck,
  FileText,
  Settings,
  LogOut,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Clock,
  ChevronRight,
  Plus,
} from "lucide-react";
import { GhostLogo } from "../components/GhostLogo";

const revenueData = [
  { mes: "Ene", ingreso: 4200, presupuesto: 5000 },
  { mes: "Feb", ingreso: 5800, presupuesto: 5500 },
  { mes: "Mar", ingreso: 4900, presupuesto: 5500 },
  { mes: "Abr", ingreso: 7100, presupuesto: 6000 },
  { mes: "May", ingreso: 6300, presupuesto: 6500 },
  { mes: "Jun", ingreso: 8200, presupuesto: 7000 },
];

const clients = [
  { id: 1, nombre: "Colegio Simón Bolívar", tipo: "Educativo", plan: "Monitoreo EDR 24/7", estado: "Activo", monto: "$850/mes" },
  { id: 2, nombre: "Farmacia Central Chacaíto", tipo: "Retail", plan: "Respaldo Híbrido", estado: "Activo", monto: "$420/mes" },
  { id: 3, nombre: "Constructora Andina C.A.", tipo: "Corporativo", plan: "Consultoría + Redes", estado: "En revisión", monto: "$2,100/mes" },
  { id: 4, nombre: "Distribuidora El Éxito", tipo: "Comercio", plan: "VPN Corporativa", estado: "Activo", monto: "$650/mes" },
  { id: 5, nombre: "Colegio Bilingüe Altamira", tipo: "Educativo", plan: "Paquete Completo", estado: "Pendiente", monto: "$1,200/mes" },
];

const diagnosticos = [
  { empresa: "Manufacturas Global", fecha: "05/06/2026", urgencia: "Alta", estado: "Por asignar" },
  { empresa: "Clínica Santa Rosa", fecha: "04/06/2026", urgencia: "Media", estado: "En proceso" },
  { empresa: "Tech Solutions VE", fecha: "03/06/2026", urgencia: "Baja", estado: "Completado" },
];

type NavItem = { label: string; icon: React.ElementType; id: string };

const navItems: NavItem[] = [
  { label: "Resumen", icon: LayoutDashboard, id: "resumen" },
  { label: "Clientes", icon: Users, id: "clientes" },
  { label: "Servicios", icon: ShieldCheck, id: "servicios" },
  { label: "Diagnósticos", icon: FileText, id: "diagnosticos" },
  { label: "Configuración", icon: Settings, id: "configuracion" },
];

const kpis = [
  { label: "Ingresos del Mes", value: "$8,200", change: "+18%", icon: TrendingUp, up: true },
  { label: "Clientes Activos", value: "24", change: "+3 este mes", icon: Users, up: true },
  { label: "Alertas Críticas", value: "2", change: "Requieren atención", icon: AlertCircle, up: false },
  { label: "Servicios Activos", value: "31", change: "En ejecución", icon: CheckCircle2, up: true },
];

export function Dashboard() {
  const [activeTab, setActiveTab] = useState("resumen");

  const sidebarW = 220;
  const topbarH = 56;

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#080808", fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif", color: "#fff" }}>

      {/* Sidebar */}
      <aside
        style={{
          width: sidebarW,
          minHeight: "100vh",
          background: "#0D0D0D",
          borderRight: "1px solid rgba(255,255,255,0.05)",
          display: "flex",
          flexDirection: "column",
          position: "fixed",
          top: 0,
          left: 0,
          bottom: 0,
          zIndex: 20,
        }}
      >
        {/* Logo */}
        <div style={{ padding: "1.5rem 1.25rem", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
          <Link to="/" style={{ display: "flex", alignItems: "center", gap: "0.6rem", textDecoration: "none" }}>
            <GhostLogo size={26} />
            <span style={{ color: "#fff", fontSize: "0.78rem", letterSpacing: "0.1em", fontWeight: 600 }}>
              PHANT<span style={{ color: "#555" }}>0</span>M
            </span>
          </Link>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: "1rem 0" }}>
          {navItems.map(item => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  gap: "0.75rem",
                  padding: "0.7rem 1.25rem",
                  background: active ? "rgba(255,255,255,0.05)" : "none",
                  border: "none",
                  borderLeft: active ? "2px solid #fff" : "2px solid transparent",
                  color: active ? "#fff" : "#444",
                  fontSize: "0.82rem",
                  cursor: "pointer",
                  textAlign: "left",
                  fontFamily: "inherit",
                  transition: "all 0.15s",
                  letterSpacing: "0.04em",
                }}
                onMouseEnter={e => { if (!active) e.currentTarget.style.color = "#888"; }}
                onMouseLeave={e => { if (!active) e.currentTarget.style.color = "#444"; }}
              >
                <Icon size={15} strokeWidth={1.5} />
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Bottom */}
        <div style={{ padding: "1rem 1.25rem", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
          <div style={{ marginBottom: "0.75rem" }}>
            <p style={{ color: "#fff", fontSize: "0.78rem", marginBottom: "0.15rem" }}>Phant0m Admin</p>
            <p style={{ color: "#333", fontSize: "0.7rem" }}>admin@phant0msecure.com</p>
          </div>
          <Link
            to="/"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
              color: "#333",
              fontSize: "0.72rem",
              textDecoration: "none",
              transition: "color 0.2s",
            }}
            onMouseEnter={e => { e.currentTarget.style.color = "#888"; }}
            onMouseLeave={e => { e.currentTarget.style.color = "#333"; }}
          >
            <LogOut size={13} />
            Cerrar Sesión
          </Link>
        </div>
      </aside>

      {/* Main */}
      <main style={{ marginLeft: sidebarW, flex: 1, minHeight: "100vh" }}>
        {/* Topbar */}
        <div
          style={{
            height: topbarH,
            background: "rgba(13,13,13,0.9)",
            backdropFilter: "blur(10px)",
            borderBottom: "1px solid rgba(255,255,255,0.05)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 2rem",
            position: "sticky",
            top: 0,
            zIndex: 10,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <span style={{ color: "#333", fontSize: "0.75rem" }}>Dashboard</span>
            <ChevronRight size={12} color="#333" />
            <span style={{ color: "#888", fontSize: "0.75rem", textTransform: "capitalize" }}>{activeTab}</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <span style={{ width: "8px", height: "8px", background: "#22c55e", borderRadius: "50%", display: "inline-block" }} />
            <span style={{ color: "#444", fontSize: "0.72rem" }}>Sistema operativo</span>
          </div>
        </div>

        <div style={{ padding: "2rem" }}>
          {/* ── RESUMEN ── */}
          {activeTab === "resumen" && (
            <div>
              <div style={{ marginBottom: "2rem" }}>
                <p style={{ color: "#444", fontSize: "0.68rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.4rem" }}>
                  Viernes, 6 de junio de 2026
                </p>
                <h2 style={{ color: "#fff", fontSize: "1.6rem", fontWeight: 300 }}>Resumen Operativo</h2>
              </div>

              {/* KPI Cards */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1px", background: "rgba(255,255,255,0.04)", marginBottom: "2rem" }}>
                {kpis.map(kpi => {
                  const Icon = kpi.icon;
                  return (
                    <div key={kpi.label} style={{ background: "#0D0D0D", padding: "1.5rem" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "1rem" }}>
                        <span style={{ color: "#333", fontSize: "0.68rem", letterSpacing: "0.12em", textTransform: "uppercase" }}>{kpi.label}</span>
                        <Icon size={14} color="#333" strokeWidth={1.5} />
                      </div>
                      <p style={{ color: "#fff", fontSize: "1.8rem", fontWeight: 300, marginBottom: "0.25rem" }}>{kpi.value}</p>
                      <p style={{ color: kpi.up ? "#4ade80" : "#f87171", fontSize: "0.72rem" }}>{kpi.change}</p>
                    </div>
                  );
                })}
              </div>

              {/* Revenue Chart */}
              <div style={{ background: "#0D0D0D", border: "1px solid rgba(255,255,255,0.05)", padding: "1.75rem", marginBottom: "2rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem" }}>
                  <div>
                    <p style={{ color: "#444", fontSize: "0.68rem", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: "0.25rem" }}>Ingresos vs Presupuesto</p>
                    <p style={{ color: "#fff", fontSize: "1rem", fontWeight: 300 }}>Primer Semestre 2026</p>
                  </div>
                  <span style={{ color: "#333", fontSize: "0.72rem" }}>USD</span>
                </div>
                <ResponsiveContainer width="100%" height={220}>
                  <AreaChart data={revenueData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="ingGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#ffffff" stopOpacity={0.1} />
                        <stop offset="95%" stopColor="#ffffff" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="presGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#444444" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#444444" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid stroke="rgba(255,255,255,0.04)" vertical={false} />
                    <XAxis dataKey="mes" tick={{ fill: "#444", fontSize: 11 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: "#444", fontSize: 11 }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{ background: "#111", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 0, color: "#fff", fontSize: "0.8rem" }}
                      labelStyle={{ color: "#888" }}
                      formatter={(val: number) => [`$${val.toLocaleString()}`, ""]}
                    />
                    <Area type="monotone" dataKey="presupuesto" stroke="#333" strokeWidth={1} fill="url(#presGrad)" name="Presupuesto" />
                    <Area type="monotone" dataKey="ingreso" stroke="#fff" strokeWidth={1.5} fill="url(#ingGrad)" name="Ingreso" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Recent Diagnostics */}
              <div style={{ background: "#0D0D0D", border: "1px solid rgba(255,255,255,0.05)", padding: "1.75rem" }}>
                <p style={{ color: "#444", fontSize: "0.68rem", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: "1.25rem" }}>
                  Diagnósticos Recientes
                </p>
                <div style={{ display: "flex", flexDirection: "column", gap: "1px", background: "rgba(255,255,255,0.04)" }}>
                  {diagnosticos.map((d, i) => (
                    <div
                      key={i}
                      style={{
                        background: "#0D0D0D",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        padding: "0.9rem 1rem",
                        flexWrap: "wrap",
                        gap: "0.5rem",
                      }}
                    >
                      <div>
                        <p style={{ color: "#fff", fontSize: "0.85rem", marginBottom: "0.2rem" }}>{d.empresa}</p>
                        <p style={{ color: "#333", fontSize: "0.72rem" }}>Solicitud: {d.fecha}</p>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
                        <span
                          style={{
                            fontSize: "0.68rem",
                            padding: "0.2rem 0.6rem",
                            border: `1px solid ${d.urgencia === "Alta" ? "rgba(248,113,113,0.4)" : d.urgencia === "Media" ? "rgba(251,191,36,0.3)" : "rgba(74,222,128,0.3)"}`,
                            color: d.urgencia === "Alta" ? "#f87171" : d.urgencia === "Media" ? "#fbbf24" : "#4ade80",
                            letterSpacing: "0.08em",
                          }}
                        >
                          {d.urgencia}
                        </span>
                        <span style={{ color: "#555", fontSize: "0.72rem" }}>{d.estado}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── CLIENTES ── */}
          {activeTab === "clientes" && (
            <div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "2rem" }}>
                <div>
                  <p style={{ color: "#444", fontSize: "0.68rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.4rem" }}>Gestión</p>
                  <h2 style={{ color: "#fff", fontSize: "1.6rem", fontWeight: 300 }}>Clientes Activos</h2>
                </div>
                <button
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "0.4rem",
                    background: "#fff",
                    color: "#000",
                    border: "none",
                    padding: "0.6rem 1.1rem",
                    fontSize: "0.75rem",
                    letterSpacing: "0.08em",
                    textTransform: "uppercase",
                    fontWeight: 600,
                    cursor: "pointer",
                    fontFamily: "inherit",
                  }}
                >
                  <Plus size={13} />
                  Nuevo Cliente
                </button>
              </div>

              <div style={{ background: "#0D0D0D", border: "1px solid rgba(255,255,255,0.05)", overflow: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                      {["Cliente", "Tipo", "Plan Activo", "Estado", "Monto Mensual"].map(h => (
                        <th key={h} style={{ textAlign: "left", padding: "0.9rem 1.25rem", color: "#333", fontSize: "0.65rem", letterSpacing: "0.15em", textTransform: "uppercase", fontWeight: 400 }}>
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {clients.map((c, i) => (
                      <tr
                        key={c.id}
                        style={{
                          borderBottom: i < clients.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none",
                          transition: "background 0.15s",
                          cursor: "pointer",
                        }}
                        onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,255,255,0.02)"; }}
                        onMouseLeave={e => { e.currentTarget.style.background = "transparent"; }}
                      >
                        <td style={{ padding: "1rem 1.25rem", color: "#fff", fontSize: "0.85rem" }}>{c.nombre}</td>
                        <td style={{ padding: "1rem 1.25rem", color: "#555", fontSize: "0.78rem" }}>{c.tipo}</td>
                        <td style={{ padding: "1rem 1.25rem", color: "#555", fontSize: "0.78rem" }}>{c.plan}</td>
                        <td style={{ padding: "1rem 1.25rem" }}>
                          <span style={{
                            fontSize: "0.68rem",
                            padding: "0.2rem 0.6rem",
                            border: `1px solid ${c.estado === "Activo" ? "rgba(74,222,128,0.3)" : c.estado === "Pendiente" ? "rgba(251,191,36,0.3)" : "rgba(148,163,184,0.3)"}`,
                            color: c.estado === "Activo" ? "#4ade80" : c.estado === "Pendiente" ? "#fbbf24" : "#94a3b8",
                            letterSpacing: "0.06em",
                          }}>
                            {c.estado}
                          </span>
                        </td>
                        <td style={{ padding: "1rem 1.25rem", color: "#fff", fontSize: "0.85rem" }}>{c.monto}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ── SERVICIOS ── */}
          {activeTab === "servicios" && (
            <div>
              <div style={{ marginBottom: "2rem" }}>
                <p style={{ color: "#444", fontSize: "0.68rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.4rem" }}>Control</p>
                <h2 style={{ color: "#fff", fontSize: "1.6rem", fontWeight: 300 }}>Servicios en Ejecución</h2>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: "1px", background: "rgba(255,255,255,0.04)" }}>
                {[
                  { nombre: "Monitoreo EDR 24/7", clientes: 14, alertas: 2, carga: 78 },
                  { nombre: "Respaldo Híbrido", clientes: 9, alertas: 0, carga: 45 },
                  { nombre: "VPN Corporativa", clientes: 6, alertas: 0, carga: 62 },
                  { nombre: "Consultorías", clientes: 3, alertas: 1, carga: 90 },
                ].map(s => (
                  <div key={s.nombre} style={{ background: "#0D0D0D", padding: "1.75rem" }}>
                    <p style={{ color: "#444", fontSize: "0.65rem", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "0.75rem" }}>
                      Servicio
                    </p>
                    <h3 style={{ color: "#fff", fontSize: "0.95rem", fontWeight: 400, marginBottom: "1.25rem" }}>{s.nombre}</h3>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "1rem" }}>
                      <div>
                        <p style={{ color: "#333", fontSize: "0.65rem", marginBottom: "0.2rem" }}>Clientes</p>
                        <p style={{ color: "#fff", fontSize: "1.2rem", fontWeight: 300 }}>{s.clientes}</p>
                      </div>
                      <div>
                        <p style={{ color: "#333", fontSize: "0.65rem", marginBottom: "0.2rem" }}>Alertas</p>
                        <p style={{ color: s.alertas > 0 ? "#f87171" : "#4ade80", fontSize: "1.2rem", fontWeight: 300 }}>{s.alertas}</p>
                      </div>
                    </div>
                    <div>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.4rem" }}>
                        <span style={{ color: "#333", fontSize: "0.65rem" }}>Carga operativa</span>
                        <span style={{ color: "#555", fontSize: "0.65rem" }}>{s.carga}%</span>
                      </div>
                      <div style={{ height: "2px", background: "rgba(255,255,255,0.06)", borderRadius: "1px" }}>
                        <div style={{ height: "2px", width: `${s.carga}%`, background: s.carga > 85 ? "#f87171" : "#fff", borderRadius: "1px", transition: "width 0.5s" }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── DIAGNÓSTICOS ── */}
          {activeTab === "diagnosticos" && (
            <div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "2rem" }}>
                <div>
                  <p style={{ color: "#444", fontSize: "0.68rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.4rem" }}>Pipeline</p>
                  <h2 style={{ color: "#fff", fontSize: "1.6rem", fontWeight: 300 }}>Solicitudes de Diagnóstico</h2>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                  <Clock size={13} color="#555" />
                  <span style={{ color: "#555", fontSize: "0.72rem" }}>Respuesta en &lt; 2 horas</span>
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "1px", background: "rgba(255,255,255,0.04)" }}>
                {[
                  ...diagnosticos,
                  { empresa: "Instituto San Gabriel", fecha: "02/06/2026", urgencia: "Media", estado: "Completado" },
                  { empresa: "Grupo Inversiones Orinoco", fecha: "01/06/2026", urgencia: "Alta", estado: "Completado" },
                ].map((d, i) => (
                  <div
                    key={i}
                    style={{
                      background: "#0D0D0D",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      padding: "1.2rem 1.5rem",
                      flexWrap: "wrap",
                      gap: "0.75rem",
                    }}
                  >
                    <div style={{ flex: 1 }}>
                      <p style={{ color: "#fff", fontSize: "0.88rem", marginBottom: "0.25rem" }}>{d.empresa}</p>
                      <p style={{ color: "#333", fontSize: "0.72rem" }}>Recibido: {d.fecha}</p>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: "1.5rem" }}>
                      <span
                        style={{
                          fontSize: "0.65rem",
                          padding: "0.2rem 0.7rem",
                          border: `1px solid ${d.urgencia === "Alta" ? "rgba(248,113,113,0.35)" : d.urgencia === "Media" ? "rgba(251,191,36,0.3)" : "rgba(74,222,128,0.3)"}`,
                          color: d.urgencia === "Alta" ? "#f87171" : d.urgencia === "Media" ? "#fbbf24" : "#4ade80",
                          letterSpacing: "0.08em",
                        }}
                      >
                        Urgencia {d.urgencia}
                      </span>
                      <span
                        style={{
                          color: d.estado === "Completado" ? "#4ade80" : d.estado === "En proceso" ? "#fbbf24" : "#555",
                          fontSize: "0.75rem",
                          minWidth: "90px",
                          textAlign: "right",
                        }}
                      >
                        {d.estado}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── CONFIGURACIÓN ── */}
          {activeTab === "configuracion" && (
            <div style={{ maxWidth: "600px" }}>
              <div style={{ marginBottom: "2rem" }}>
                <p style={{ color: "#444", fontSize: "0.68rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.4rem" }}>Sistema</p>
                <h2 style={{ color: "#fff", fontSize: "1.6rem", fontWeight: 300 }}>Configuración</h2>
              </div>
              {[
                { label: "Empresa", valor: "Phant0m Secure" },
                { label: "Administrador", valor: "Phant0m Admin" },
                { label: "Correo", valor: "admin@phant0msecure.com" },
                { label: "Ubicación", valor: "Caracas, Venezuela" },
                { label: "Plan de sistema", valor: "Empresarial — Ilimitado" },
              ].map(item => (
                <div
                  key={item.label}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "1.1rem 0",
                    borderBottom: "1px solid rgba(255,255,255,0.05)",
                  }}
                >
                  <span style={{ color: "#444", fontSize: "0.78rem", letterSpacing: "0.06em" }}>{item.label}</span>
                  <span style={{ color: "#fff", fontSize: "0.85rem" }}>{item.valor}</span>
                </div>
              ))}
              <button
                style={{
                  marginTop: "2rem",
                  background: "transparent",
                  border: "1px solid rgba(255,255,255,0.15)",
                  color: "#888",
                  padding: "0.7rem 1.5rem",
                  fontSize: "0.78rem",
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  cursor: "pointer",
                  fontFamily: "inherit",
                  transition: "all 0.2s",
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = "#fff"; e.currentTarget.style.color = "#fff"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)"; e.currentTarget.style.color = "#888"; }}
              >
                Editar Perfil
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
