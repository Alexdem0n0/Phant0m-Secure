import { DynamicBackground } from "../components/DynamicBackground";
import { Navbar } from "../components/Navbar";
import { Hero } from "../components/Hero";
import { Context } from "../components/Context";
import { Services } from "../components/Services";
import { Scale } from "../components/Scale";
import { Blog } from "../components/Blog";
import { FAQ } from "../components/FAQ";
import { Contact } from "../components/Contact";
import { Footer } from "../components/Footer";

export function Landing() {
  return (
    <div style={{ position: "relative", fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif" }}>
      <DynamicBackground />
      {/* All sections sit above the fixed background */}
      <div style={{ position: "relative", zIndex: 1 }}>
        <Navbar />
        <Hero />
        <Context />
        <Services />
        <Scale />
        <Blog />
        <FAQ />
        <Contact />
        <Footer />
      </div>
    </div>
  );
}
