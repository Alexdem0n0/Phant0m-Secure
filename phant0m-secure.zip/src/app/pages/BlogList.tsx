import { Link } from "react-router";
import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { blogPosts } from "../data/blogPosts";
import { GhostLogo } from "../components/GhostLogo";

export function BlogList() {
  return (
    <div style={{ background: "#0D0D0D", minHeight: "100vh", fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif" }}>
      {/* Minimal nav */}
      <nav
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "1.5rem 2rem",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <Link to="/" style={{ display: "flex", alignItems: "center", gap: "0.6rem", textDecoration: "none" }}>
          <GhostLogo size={28} />
          <span style={{ color: "#fff", fontSize: "0.85rem", letterSpacing: "0.12em", fontWeight: 600 }}>
            PHANT<span style={{ color: "#555" }}>0</span>M SECURE
          </span>
        </Link>
        <Link
          to="/"
          style={{ color: "#444", fontSize: "0.75rem", letterSpacing: "0.08em", textDecoration: "none", textTransform: "uppercase" }}
          onMouseEnter={e => { e.currentTarget.style.color = "#fff"; }}
          onMouseLeave={e => { e.currentTarget.style.color = "#444"; }}
        >
          ← Volver al Inicio
        </Link>
      </nav>

      <div style={{ maxWidth: "1100px", margin: "0 auto", padding: "4rem 2rem" }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          style={{ marginBottom: "4rem" }}
        >
          <p style={{ color: "#444", fontSize: "0.68rem", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: "1rem" }}>
            Conocimiento · Prevención Corporativa
          </p>
          <h1
            style={{
              color: "#fff",
              fontSize: "clamp(2rem, 5vw, 3.5rem)",
              fontWeight: 300,
              lineHeight: 1.1,
              marginBottom: "1rem",
            }}
          >
            Blog de Ciberseguridad
          </h1>
          <p style={{ color: "#555", fontSize: "0.95rem", lineHeight: 1.8, maxWidth: "520px" }}>
            Artículos educativos para proteger su organización. Sin tecnicismos innecesarios,
            sin alarmismo. Solo información accionable.
          </p>
        </motion.div>

        {/* Featured post */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15 }}
          style={{ marginBottom: "1px" }}
        >
          <Link
            to={`/blog/${blogPosts[0].slug}`}
            style={{ textDecoration: "none", display: "block" }}
          >
            <div
              style={{
                background: "#111",
                padding: "3rem",
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "3rem",
                alignItems: "center",
                transition: "background 0.2s",
                cursor: "pointer",
              }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#161616"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#111"; }}
            >
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "1.5rem" }}>
                  <span style={{ color: "#222", fontSize: "0.65rem", letterSpacing: "0.2em" }}>{blogPosts[0].number}</span>
                  <span style={{ color: "#333", fontSize: "0.65rem", letterSpacing: "0.12em", textTransform: "uppercase" }}>{blogPosts[0].category}</span>
                  <span style={{ color: "#222", fontSize: "0.65rem" }}>·</span>
                  <span style={{ color: "#333", fontSize: "0.65rem" }}>{blogPosts[0].readTime}</span>
                </div>
                <h2 style={{ color: "#fff", fontSize: "clamp(1.2rem, 2.5vw, 1.6rem)", fontWeight: 300, lineHeight: 1.4, marginBottom: "1.25rem" }}>
                  {blogPosts[0].title}
                </h2>
                <p style={{ color: "#555", fontSize: "0.88rem", lineHeight: 1.8, marginBottom: "1.5rem" }}>
                  {blogPosts[0].summary}
                </p>
                <div style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
                  <span style={{ color: "#666", fontSize: "0.75rem", letterSpacing: "0.06em" }}>Leer artículo</span>
                  <ArrowUpRight size={13} color="#666" />
                </div>
              </div>
              <div
                style={{
                  background: "#0D0D0D",
                  height: "240px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  border: "1px solid rgba(255,255,255,0.04)",
                }}
              >
                <div style={{ textAlign: "center" }}>
                  <p style={{ color: "#1a1a1a", fontSize: "5rem", fontWeight: 300, lineHeight: 1 }}>01</p>
                  <p style={{ color: "#333", fontSize: "0.65rem", letterSpacing: "0.2em", textTransform: "uppercase" }}>Factor Humano</p>
                </div>
              </div>
            </div>
          </Link>
        </motion.div>

        {/* Rest of posts */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "1px", background: "rgba(255,255,255,0.04)" }}>
          {blogPosts.slice(1).map((post, i) => (
            <motion.div
              key={post.slug}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 + i * 0.12 }}
            >
              <Link
                to={`/blog/${post.slug}`}
                style={{ textDecoration: "none", display: "block", height: "100%" }}
              >
                <div
                  style={{
                    background: "#0D0D0D",
                    padding: "2.5rem",
                    display: "flex",
                    flexDirection: "column",
                    gap: "1rem",
                    height: "100%",
                    boxSizing: "border-box",
                    transition: "background 0.2s",
                  }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#111"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#0D0D0D"; }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <span style={{ color: "#222", fontSize: "0.65rem", letterSpacing: "0.2em" }}>{post.number}</span>
                    <span style={{ color: "#333", fontSize: "0.65rem", letterSpacing: "0.12em", textTransform: "uppercase" }}>{post.category}</span>
                  </div>
                  <h3 style={{ color: "#fff", fontSize: "1rem", fontWeight: 400, lineHeight: 1.5, flex: 1 }}>{post.title}</h3>
                  <p style={{ color: "#555", fontSize: "0.82rem", lineHeight: 1.7 }}>{post.summary}</p>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: "1rem", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
                    <span style={{ color: "#333", fontSize: "0.72rem" }}>{post.readTime}</span>
                    <ArrowUpRight size={14} color="#444" />
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
