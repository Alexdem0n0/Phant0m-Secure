import { useParams, Link, Navigate } from "react-router";
import { motion } from "motion/react";
import { ArrowLeft, Clock, Tag } from "lucide-react";
import { getPostBySlug, blogPosts } from "../data/blogPosts";
import { GhostLogo } from "../components/GhostLogo";

export function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const post = getPostBySlug(slug ?? "");

  if (!post) return <Navigate to="/blog" replace />;

  const currentIndex = blogPosts.findIndex(p => p.slug === slug);
  const prev = blogPosts[currentIndex - 1];
  const next = blogPosts[currentIndex + 1];

  return (
    <div style={{ background: "#0D0D0D", minHeight: "100vh", fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif" }}>
      {/* Nav */}
      <nav
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "1.5rem 2rem",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
          position: "sticky",
          top: 0,
          background: "rgba(13,13,13,0.9)",
          backdropFilter: "blur(12px)",
          zIndex: 10,
        }}
      >
        <Link to="/" style={{ display: "flex", alignItems: "center", gap: "0.6rem", textDecoration: "none" }}>
          <GhostLogo size={26} />
          <span style={{ color: "#fff", fontSize: "0.82rem", letterSpacing: "0.12em", fontWeight: 600 }}>
            PHANT<span style={{ color: "#555" }}>0</span>M SECURE
          </span>
        </Link>
        <Link
          to="/blog"
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.4rem",
            color: "#444",
            fontSize: "0.75rem",
            letterSpacing: "0.08em",
            textDecoration: "none",
            textTransform: "uppercase",
            transition: "color 0.2s",
          }}
          onMouseEnter={e => { e.currentTarget.style.color = "#fff"; }}
          onMouseLeave={e => { e.currentTarget.style.color = "#444"; }}
        >
          <ArrowLeft size={13} />
          Blog
        </Link>
      </nav>

      <div style={{ maxWidth: "760px", margin: "0 auto", padding: "4rem 2rem 6rem" }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          style={{ marginBottom: "3.5rem" }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "2rem", flexWrap: "wrap" }}>
            <span style={{ color: "#222", fontSize: "0.65rem", letterSpacing: "0.2em" }}>{post.number}</span>
            <span style={{ color: "#333", fontSize: "0.65rem", letterSpacing: "0.12em", textTransform: "uppercase" }}>{post.category}</span>
            <span style={{ color: "#222" }}>·</span>
            <span style={{ display: "flex", alignItems: "center", gap: "0.3rem", color: "#333", fontSize: "0.65rem" }}>
              <Clock size={10} />
              {post.readTime}
            </span>
            <span style={{ color: "#222" }}>·</span>
            <span style={{ color: "#333", fontSize: "0.65rem" }}>{post.date}</span>
          </div>

          <h1
            style={{
              color: "#fff",
              fontSize: "clamp(1.6rem, 4vw, 2.6rem)",
              fontWeight: 300,
              lineHeight: 1.2,
              marginBottom: "1.5rem",
            }}
          >
            {post.title}
          </h1>

          <p
            style={{
              color: "#666",
              fontSize: "1.05rem",
              lineHeight: 1.8,
              fontStyle: "italic",
              borderLeft: "2px solid rgba(255,255,255,0.1)",
              paddingLeft: "1.25rem",
            }}
          >
            {post.summary}
          </p>
        </motion.div>

        {/* Divider */}
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.05)", marginBottom: "3rem" }} />

        {/* Article body */}
        <motion.article
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {post.sections.map((section, i) => (
            <div key={i} style={{ marginBottom: "2.5rem" }}>
              {section.heading && (
                <h2
                  style={{
                    color: "#fff",
                    fontSize: "1.1rem",
                    fontWeight: 400,
                    marginBottom: "1rem",
                    paddingTop: i > 0 ? "0.5rem" : 0,
                  }}
                >
                  {section.heading}
                </h2>
              )}
              {section.body.split("\n\n").map((paragraph, j) => (
                <p
                  key={j}
                  style={{
                    color: "#666",
                    fontSize: "0.95rem",
                    lineHeight: 1.9,
                    marginBottom: "1rem",
                  }}
                >
                  {paragraph}
                </p>
              ))}
            </div>
          ))}
        </motion.article>

        {/* Tags */}
        <div style={{ marginTop: "3rem", paddingTop: "2rem", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", flexWrap: "wrap" }}>
            <Tag size={12} color="#333" />
            {post.tags.map(tag => (
              <span
                key={tag}
                style={{
                  color: "#333",
                  fontSize: "0.65rem",
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                  border: "1px solid rgba(255,255,255,0.06)",
                  padding: "0.2rem 0.6rem",
                }}
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Author */}
        <div
          style={{
            marginTop: "2rem",
            padding: "1.5rem",
            background: "#111",
            display: "flex",
            alignItems: "center",
            gap: "1rem",
          }}
        >
          <div style={{ width: "36px", height: "36px", background: "#0D0D0D", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <GhostLogo size={20} />
          </div>
          <div>
            <p style={{ color: "#fff", fontSize: "0.82rem", marginBottom: "0.15rem" }}>{post.author}</p>
            <p style={{ color: "#333", fontSize: "0.72rem" }}>Caracas, Venezuela · phant0msecure.com</p>
          </div>
        </div>

        {/* Prev / Next */}
        <div style={{ marginTop: "3rem", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1px", background: "rgba(255,255,255,0.04)" }}>
          {prev ? (
            <Link
              to={`/blog/${prev.slug}`}
              style={{ textDecoration: "none", display: "block" }}
            >
              <div
                style={{ background: "#0D0D0D", padding: "1.5rem", transition: "background 0.2s" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#111"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#0D0D0D"; }}
              >
                <p style={{ color: "#333", fontSize: "0.65rem", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "0.5rem" }}>← Anterior</p>
                <p style={{ color: "#888", fontSize: "0.82rem", lineHeight: 1.4 }}>{prev.title}</p>
              </div>
            </Link>
          ) : <div />}

          {next ? (
            <Link
              to={`/blog/${next.slug}`}
              style={{ textDecoration: "none", display: "block" }}
            >
              <div
                style={{ background: "#0D0D0D", padding: "1.5rem", textAlign: "right", transition: "background 0.2s" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#111"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#0D0D0D"; }}
              >
                <p style={{ color: "#333", fontSize: "0.65rem", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "0.5rem" }}>Siguiente →</p>
                <p style={{ color: "#888", fontSize: "0.82rem", lineHeight: 1.4 }}>{next.title}</p>
              </div>
            </Link>
          ) : <div />}
        </div>

        {/* CTA */}
        <div
          style={{
            marginTop: "3rem",
            padding: "2.5rem",
            background: "#111",
            textAlign: "center",
          }}
        >
          <p style={{ color: "#fff", fontSize: "1rem", fontWeight: 300, marginBottom: "0.75rem" }}>
            ¿Su organización está protegida?
          </p>
          <p style={{ color: "#555", fontSize: "0.82rem", marginBottom: "1.5rem" }}>
            Solicite un diagnóstico de riesgo sin costo en menos de 2 horas.
          </p>
          <Link
            to="/#contacto"
            style={{
              background: "#fff",
              color: "#000",
              padding: "0.7rem 1.75rem",
              fontSize: "0.78rem",
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              textDecoration: "none",
              fontWeight: 600,
              display: "inline-block",
              transition: "background 0.2s",
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#ddd"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#fff"; }}
          >
            Solicitar Diagnóstico
          </Link>
        </div>
      </div>
    </div>
  );
}
