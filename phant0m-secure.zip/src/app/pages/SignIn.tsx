import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { motion } from "motion/react";
import { GhostLogo } from "../components/GhostLogo";

export function SignIn() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  const handle = (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.email || !form.password) {
      setError("Por favor complete todos los campos.");
      return;
    }
    // Mock authentication — navigate to dashboard
    navigate("/dashboard");
  };

  const inputStyle: React.CSSProperties = {
    width: "100%",
    background: "transparent",
    border: "none",
    borderBottom: "1px solid rgba(255,255,255,0.12)",
    color: "#fff",
    padding: "0.75rem 0",
    fontSize: "0.9rem",
    outline: "none",
    fontFamily: "inherit",
    transition: "border-color 0.2s",
    boxSizing: "border-box",
  };

  const labelStyle: React.CSSProperties = {
    color: "#444",
    fontSize: "0.68rem",
    letterSpacing: "0.18em",
    textTransform: "uppercase",
    display: "block",
    marginBottom: "0.25rem",
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#0D0D0D",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
        padding: "2rem",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Subtle grid */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.015) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.015) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
          pointerEvents: "none",
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
        style={{ position: "relative", zIndex: 1, width: "100%", maxWidth: "420px" }}
      >
        {/* Logo */}
        <Link to="/" style={{ display: "flex", alignItems: "center", gap: "0.6rem", textDecoration: "none", marginBottom: "3rem" }}>
          <GhostLogo size={28} />
          <span style={{ color: "#fff", fontSize: "0.85rem", letterSpacing: "0.12em", fontWeight: 600 }}>
            PHANT<span style={{ color: "#666" }}>0</span>M SECURE
          </span>
        </Link>

        <p style={{ color: "#444", fontSize: "0.68rem", letterSpacing: "0.22em", textTransform: "uppercase", marginBottom: "0.75rem" }}>
          Acceso Empresarial
        </p>
        <h1
          style={{
            color: "#fff",
            fontSize: "clamp(1.6rem, 4vw, 2.2rem)",
            fontWeight: 300,
            lineHeight: 1.2,
            marginBottom: "2.5rem",
          }}
        >
          Iniciar Sesión
        </h1>

        <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: "2rem" }}>
          <div>
            <label style={labelStyle}>Correo Electrónico</label>
            <input
              name="email"
              type="email"
              value={form.email}
              onChange={handle}
              placeholder="correo@empresa.com"
              style={inputStyle}
              onFocus={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.5)"; }}
              onBlur={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.12)"; }}
            />
          </div>

          <div>
            <label style={labelStyle}>Contraseña</label>
            <input
              name="password"
              type="password"
              value={form.password}
              onChange={handle}
              placeholder="••••••••"
              style={inputStyle}
              onFocus={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.5)"; }}
              onBlur={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.12)"; }}
            />
          </div>

          {error && (
            <p style={{ color: "#c0392b", fontSize: "0.78rem" }}>{error}</p>
          )}

          <button
            type="submit"
            style={{
              background: "#fff",
              color: "#000",
              border: "none",
              padding: "0.9rem",
              fontSize: "0.8rem",
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              fontWeight: 600,
              cursor: "pointer",
              fontFamily: "inherit",
              transition: "background 0.2s",
              marginTop: "0.5rem",
            }}
            onMouseEnter={e => { e.currentTarget.style.background = "#ddd"; }}
            onMouseLeave={e => { e.currentTarget.style.background = "#fff"; }}
          >
            Ingresar al Sistema
          </button>
        </form>

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "2rem" }}>
          <span style={{ color: "#333", fontSize: "0.78rem" }}>
            ¿No tiene cuenta?{" "}
            <Link to="/signup" style={{ color: "#aaa", textDecoration: "none" }}
              onMouseEnter={e => { e.currentTarget.style.color = "#fff"; }}
              onMouseLeave={e => { e.currentTarget.style.color = "#aaa"; }}
            >
              Registrarse
            </Link>
          </span>
          <Link
            to="/"
            style={{ color: "#333", fontSize: "0.72rem", textDecoration: "none", letterSpacing: "0.06em" }}
            onMouseEnter={e => { e.currentTarget.style.color = "#666"; }}
            onMouseLeave={e => { e.currentTarget.style.color = "#333"; }}
          >
            ← Volver al Inicio
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
