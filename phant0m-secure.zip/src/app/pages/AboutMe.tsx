import { useEffect, useState } from "react";
import { motion } from "motion/react";
import {
  Github,
  ExternalLink,
  MapPin,
  Link2,
  Users,
  BookOpen,
  Star,
  GitFork,
} from "lucide-react";
import { DynamicBackground } from "../components/DynamicBackground";
import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";

const GITHUB_USERNAME = "Alexdem0n0";
const GITHUB_URL = `https://github.com/${GITHUB_USERNAME}`;

interface GithubUser {
  login: string;
  name: string | null;
  bio: string | null;
  avatar_url: string;
  html_url: string;
  location: string | null;
  blog: string | null;
  public_repos: number;
  followers: number;
  following: number;
  company: string | null;
}

interface GithubRepo {
  id: number;
  name: string;
  description: string | null;
  html_url: string;
  stargazers_count: number;
  forks_count: number;
  language: string | null;
  fork: boolean;
}

const cardStyle: React.CSSProperties = {
  border: "1px solid rgba(255,255,255,0.08)",
  background: "rgba(13,13,13,0.85)",
  backdropFilter: "blur(12px)",
  padding: "2rem",
  boxSizing: "border-box",
};

const labelStyle: React.CSSProperties = {
  color: "#555",
  fontSize: "0.65rem",
  letterSpacing: "0.2em",
  textTransform: "uppercase",
  marginBottom: "1rem",
};

export function AboutMe() {
  const [user, setUser] = useState<GithubUser | null>(null);
  const [repos, setRepos] = useState<GithubRepo[]>([]);
  const [status, setStatus] = useState<"loading" | "ok" | "error">("loading");

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const [userRes, reposRes] = await Promise.all([
          fetch(`https://api.github.com/users/${GITHUB_USERNAME}`),
          fetch(
            `https://api.github.com/users/${GITHUB_USERNAME}/repos?sort=updated&per_page=100`
          ),
        ]);

        if (!userRes.ok) throw new Error("user fetch failed");

        const userData: GithubUser = await userRes.json();
        let repoData: GithubRepo[] = [];

        if (reposRes.ok) {
          const allRepos: GithubRepo[] = await reposRes.json();
          repoData = allRepos
            .filter((r) => !r.fork)
            .sort((a, b) => b.stargazers_count - a.stargazers_count)
            .slice(0, 6);
        }

        if (!cancelled) {
          setUser(userData);
          setRepos(repoData);
          setStatus("ok");
        }
      } catch {
        if (!cancelled) setStatus("error");
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div style={{ position: "relative", fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif" }}>
      <DynamicBackground />
      <div style={{ position: "relative", zIndex: 1 }}>
        <Navbar />

        <section
          style={{
            minHeight: "100vh",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            padding: "8rem 2rem 6rem",
            position: "relative",
            overflow: "hidden",
          }}
        >
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: "easeOut" }}
            style={{ position: "relative", zIndex: 1, maxWidth: "900px", width: "100%", textAlign: "center" }}
          >
            <p
              style={{
                color: "#555",
                fontSize: "0.72rem",
                letterSpacing: "0.25em",
                textTransform: "uppercase",
                marginBottom: "2rem",
              }}
            >
              Sobre Mí
            </p>

            <h1
              style={{
                color: "#fff",
                fontSize: "clamp(2.2rem, 6vw, 4.5rem)",
                fontWeight: 300,
                lineHeight: 1.1,
                letterSpacing: "-0.02em",
                marginBottom: "1.5rem",
              }}
            >
              Alex<span style={{ color: "#888" }}>__dem0n</span>
            </h1>

            <p
              style={{
                color: "#aaa",
                fontSize: "1rem",
                lineHeight: 1.8,
                maxWidth: "640px",
                margin: "0 auto 0",
              }}
            >
              Desarrollador y entusiasta de la ciberseguridad. Esta es mi
              actividad pública en GitHub, en vivo.
            </p>
          </motion.div>

          {/* GitHub profile card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: "easeOut", delay: 0.15 }}
            style={{
              position: "relative",
              zIndex: 1,
              width: "100%",
              maxWidth: "900px",
              marginTop: "4rem",
            }}
          >
            {status === "loading" && (
              <div style={{ ...cardStyle, textAlign: "center", color: "#666", fontSize: "0.85rem" }}>
                Cargando perfil de GitHub…
              </div>
            )}

            {status === "error" && (
              <div style={{ ...cardStyle, textAlign: "center" }}>
                <p style={{ color: "#888", fontSize: "0.85rem", marginBottom: "1.5rem" }}>
                  No se pudo cargar el perfil en este momento.
                </p>
                <a
                  href={GITHUB_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "0.6rem",
                    background: "#fff",
                    color: "#000",
                    padding: "0.75rem 1.6rem",
                    fontSize: "0.82rem",
                    letterSpacing: "0.08em",
                    textTransform: "uppercase",
                    textDecoration: "none",
                    fontWeight: 600,
                  }}
                >
                  <Github size={18} />
                  Ver perfil en GitHub
                  <ExternalLink size={14} />
                </a>
              </div>
            )}

            {status === "ok" && user && (
              <div style={cardStyle}>
                <div
                  style={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: "2rem",
                    alignItems: "flex-start",
                  }}
                >
                  <img
                    src={user.avatar_url}
                    alt={`Avatar de ${user.login}`}
                    style={{
                      width: "120px",
                      height: "120px",
                      borderRadius: "50%",
                      border: "1px solid rgba(255,255,255,0.1)",
                      objectFit: "cover",
                    }}
                  />

                  <div style={{ flex: "1 1 280px", textAlign: "left" }}>
                    <h2 style={{ color: "#fff", fontSize: "1.4rem", fontWeight: 500, margin: 0 }}>
                      {user.name || user.login}
                    </h2>
                    <p style={{ color: "#666", fontSize: "0.85rem", marginTop: "0.25rem", marginBottom: "1rem" }}>
                      @{user.login}
                    </p>

                    {user.bio && (
                      <p style={{ color: "#aaa", fontSize: "0.9rem", lineHeight: 1.7, marginBottom: "1.25rem" }}>
                        {user.bio}
                      </p>
                    )}

                    <div style={{ display: "flex", flexWrap: "wrap", gap: "1.25rem", marginBottom: "1.5rem" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", color: "#888", fontSize: "0.8rem" }}>
                        <BookOpen size={15} />
                        {user.public_repos} repositorios
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", color: "#888", fontSize: "0.8rem" }}>
                        <Users size={15} />
                        {user.followers} seguidores · {user.following} siguiendo
                      </div>
                      {user.location && (
                        <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", color: "#888", fontSize: "0.8rem" }}>
                          <MapPin size={15} />
                          {user.location}
                        </div>
                      )}
                      {user.blog && (
                        <a
                          href={user.blog.startsWith("http") ? user.blog : `https://${user.blog}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{ display: "flex", alignItems: "center", gap: "0.4rem", color: "#888", fontSize: "0.8rem", textDecoration: "none" }}
                        >
                          <Link2 size={15} />
                          {user.blog}
                        </a>
                      )}
                    </div>

                    <a
                      href={GITHUB_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "0.6rem",
                        background: "#fff",
                        color: "#000",
                        padding: "0.6rem 1.4rem",
                        fontSize: "0.78rem",
                        letterSpacing: "0.08em",
                        textTransform: "uppercase",
                        textDecoration: "none",
                        fontWeight: 600,
                      }}
                    >
                      <Github size={16} />
                      Ver perfil completo
                      <ExternalLink size={13} />
                    </a>
                  </div>
                </div>
              </div>
            )}
          </motion.div>

          {/* Repos */}
          {status === "ok" && repos.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, ease: "easeOut", delay: 0.25 }}
              style={{
                position: "relative",
                zIndex: 1,
                width: "100%",
                maxWidth: "900px",
                marginTop: "2rem",
              }}
            >
              <div style={cardStyle}>
                <p style={{ ...labelStyle, marginBottom: "1.5rem" }}>Repositorios</p>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
                    gap: "1rem",
                  }}
                >
                  {repos.map((repo) => (
                    <a
                      key={repo.id}
                      href={repo.html_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        display: "block",
                        border: "1px solid rgba(255,255,255,0.06)",
                        padding: "1rem",
                        textDecoration: "none",
                        transition: "border-color 0.2s",
                      }}
                      onMouseEnter={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.2)"; }}
                      onMouseLeave={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.06)"; }}
                    >
                      <p style={{ color: "#fff", fontSize: "0.9rem", fontWeight: 500, marginBottom: "0.4rem" }}>
                        {repo.name}
                      </p>
                      {repo.description && (
                        <p style={{ color: "#777", fontSize: "0.78rem", lineHeight: 1.5, marginBottom: "0.75rem", minHeight: "2.2em" }}>
                          {repo.description}
                        </p>
                      )}
                      <div style={{ display: "flex", gap: "1rem", color: "#555", fontSize: "0.72rem" }}>
                        {repo.language && <span>{repo.language}</span>}
                        <span style={{ display: "flex", alignItems: "center", gap: "0.25rem" }}>
                          <Star size={12} /> {repo.stargazers_count}
                        </span>
                        <span style={{ display: "flex", alignItems: "center", gap: "0.25rem" }}>
                          <GitFork size={12} /> {repo.forks_count}
                        </span>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </section>

        <Footer />
      </div>
    </div>
  );
}
