import { Outlet } from "react-router";
import { Watermark } from "./components/Watermark";

export function Root() {
  return (
    <>
      <Outlet />
      <Watermark />
    </>
  );
}
