import { createBrowserRouter } from "react-router";
import { Root } from "./Root";
import { Landing } from "./pages/Landing";
import { SignIn } from "./pages/SignIn";
import { SignUp } from "./pages/SignUp";
import { Dashboard } from "./pages/Dashboard";
import { BlogList } from "./pages/BlogList";
import { BlogPost } from "./pages/BlogPost";
import { AboutMe } from "./pages/AboutMe";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Landing },
      { path: "signin", Component: SignIn },
      { path: "signup", Component: SignUp },
      { path: "dashboard", Component: Dashboard },
      { path: "blog", Component: BlogList },
      { path: "blog/:slug", Component: BlogPost },
      { path: "sobre-mi", Component: AboutMe },
    ],
  },
]);
