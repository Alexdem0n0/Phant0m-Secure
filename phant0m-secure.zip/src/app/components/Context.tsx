import { motion } from "motion/react";

export function Context() {
  return (
    <section
      style={{
        background: "rgba(10,10,10,0.82)",
        padding: "6rem 2rem",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Texture overlay */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage:
            "radial-gradient(circle at 20% 50%, rgba(255,255,255,0.015) 0%, transparent 60%), radial-gradient(circle at 80% 50%, rgba(255,255,255,0.01) 0%, transparent 60%)",
          pointerEvents: "none",
        }}
      />

      <div style={{ maxWidth: "1100px", margin: "0 auto", position: "relative", zIndex: 1 }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <p style={{ color: "#444", fontSize: "0.72rem", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: "1rem" }}>
            El Factor Humano
          </p>
          <h2
            style={{
              color: "#fff",
              fontSize: "clamp(1.6rem, 4vw, 3rem)",
              fontWeight: 300,
              lineHeight: 1.2,
              marginBottom: "3rem",
              maxWidth: "700px",
            }}
          >
            La mayor vulnerabilidad no está
            <br />
            <span style={{ color: "#666" }}>en sus sistemas. Está en las personas.</span>
          </h2>
        </motion.div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "2px" }}>
          {[
            {
              number: "01",
              title: "El Empleado Saliente",
              desc: "La negligencia interna o la malicia de un colaborador que abandona la organización puede apropiarse o borrar información crítica, dejando vacíos irreparables en el activo más valioso de su empresa: su datos históricos.",
            },
            {
              number: "02",
              title: "El Riesgo Estructural",
              desc: "Cuando los datos pertenecen al individuo y no a la institución, la empresa queda expuesta. Un solo acceso sin revocar puede ser la puerta de entrada a una crisis operativa total.",
            },
            {
              number: "03",
              title: "La Solución Phant0m",
              desc: "Aislamos sus datos para que pertenezcan a la institución y no al individuo, eliminando el riesgo humano antes de que se convierta en una crisis. Visibilidad total, sin intervención visible.",
            },
          ].map((item, i) => (
            <motion.div
              key={item.number}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              style={{
                background: "rgba(8,8,8,0.75)",
                padding: "2.5rem",
                borderTop: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <span style={{ color: "#333", fontSize: "0.65rem", letterSpacing: "0.2em" }}>{item.number}</span>
              <h3 style={{ color: "#fff", fontSize: "1.1rem", fontWeight: 400, margin: "0.75rem 0 1rem" }}>{item.title}</h3>
              <p style={{ color: "#555", fontSize: "0.88rem", lineHeight: 1.8 }}>{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
