import { motion } from "motion/react";
import { Building2, GraduationCap, Store, Landmark } from "lucide-react";

const clients = [
  { icon: Store, label: "Comercio Minorista", desc: "Tiendas y negocios locales" },
  { icon: GraduationCap, label: "Sector Educativo", desc: "Colegios e instituciones privadas" },
  { icon: Building2, label: "PYMES", desc: "Pequeñas y medianas empresas" },
  { icon: Landmark, label: "Grandes Corporaciones", desc: "Infraestructuras críticas" },
];

export function Scale() {
  return (
    <section id="alcance" style={{ background: "rgba(10,10,10,0.82)", padding: "6rem 2rem" }}>
      <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          style={{ textAlign: "center", marginBottom: "4rem" }}
        >
          <p style={{ color: "#444", fontSize: "0.72rem", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: "1rem" }}>
            Alcance
          </p>
          <h2 style={{ color: "#fff", fontSize: "clamp(1.6rem, 4vw, 3rem)", fontWeight: 300, lineHeight: 1.2, marginBottom: "1.5rem" }}>
            Seguridad Sin Importar la Escala
          </h2>
          <p style={{ color: "#555", fontSize: "0.95rem", lineHeight: 1.9, maxWidth: "700px", margin: "0 auto" }}>
            Nuestra arquitectura de protección es completamente modular y flexible. Nos adaptamos
            a las realidades de cualquier organización privada: desde los negocios e instituciones
            locales más pequeñas, hasta los consorcios masivos que manejan infraestructuras críticas.
          </p>
        </motion.div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1px", background: "rgba(255,255,255,0.04)", marginBottom: "3rem" }}>
          {clients.map((client, i) => {
            const Icon = client.icon;
            return (
              <motion.div
                key={client.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                style={{
                  background: "rgba(8,8,8,0.7)",
                  padding: "2rem",
                  textAlign: "center",
                }}
              >
                <Icon size={24} color="#666" strokeWidth={1} style={{ marginBottom: "1rem" }} />
                <p style={{ color: "#fff", fontSize: "0.9rem", fontWeight: 400, marginBottom: "0.4rem" }}>{client.label}</p>
                <p style={{ color: "#444", fontSize: "0.78rem" }}>{client.desc}</p>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          style={{
            border: "1px solid rgba(255,255,255,0.06)",
            padding: "2rem 2.5rem",
            display: "flex",
            alignItems: "flex-start",
            gap: "1rem",
          }}
        >
          <span style={{ color: "#333", fontSize: "1.2rem", flexShrink: 0, marginTop: "2px" }}>※</span>
          <p style={{ color: "#444", fontSize: "0.82rem", lineHeight: 1.8, margin: 0 }}>
            <strong style={{ color: "#666" }}>Nota:</strong> Phant0m Secure no presta servicios a entidades gubernamentales. Nos enfocamos
            exclusivamente en potenciar y proteger el sector comercial y educativo privado.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
