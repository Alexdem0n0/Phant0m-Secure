import { motion } from "motion/react";

export function Hero() {
  return (
    <section
      style={{
        minHeight: "100vh",
        background: "transparent",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
        padding: "8rem 2rem 4rem",
        position: "relative",
        overflow: "hidden",
      }}
    >

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: "easeOut" }}
        style={{ position: "relative", zIndex: 1, maxWidth: "900px" }}
      >
        <p
          style={{
            color: "#555",
            fontSize: "0.72rem",
            letterSpacing: "0.25em",
            textTransform: "uppercase",
            marginBottom: "2rem",
          }}
        >
          Ciberseguridad Estratégica · Caracas, Venezuela
        </p>

        <h1
          style={{
            color: "#fff",
            fontSize: "clamp(2.2rem, 6vw, 4.5rem)",
            fontWeight: 300,
            lineHeight: 1.1,
            letterSpacing: "-0.02em",
            marginBottom: "1.5rem",
          }}
        >
          Arquitectura de Resiliencia
          <br />
          <span style={{ color: "#888" }}>Digital y Continuidad</span>
          <br />
          de Negocio
        </h1>

        <p
          style={{
            color: "#aaa",
            fontSize: "clamp(1rem, 2.5vw, 1.4rem)",
            fontWeight: 300,
            letterSpacing: "0.04em",
            marginBottom: "1.5rem",
            fontStyle: "italic",
          }}
        >
          "Protección que no ves, seguridad que sientes."
        </p>

        <p
          style={{
            color: "#666",
            fontSize: "clamp(0.85rem, 1.5vw, 1rem)",
            lineHeight: 1.8,
            maxWidth: "620px",
            margin: "0 auto 3rem",
          }}
        >
          Blindamos la infraestructura y los activos digitales del sector comercial privado contra
          ataques externos y fallas operativas humanas. Diseñado para garantizar estabilidad
          operativa absoluta.
        </p>

        <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
          <a
            href="#contacto"
            style={{
              background: "#fff",
              color: "#000",
              padding: "0.85rem 2rem",
              fontSize: "0.82rem",
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              textDecoration: "none",
              fontWeight: 600,
              transition: "background 0.2s",
              display: "inline-block",
            }}
            onMouseEnter={e => { e.currentTarget.style.background = "#ddd"; }}
            onMouseLeave={e => { e.currentTarget.style.background = "#fff"; }}
          >
            Solicitar Diagnóstico de Riesgo
          </a>
          <a
            href="#servicios"
            style={{
              border: "1px solid rgba(255,255,255,0.4)",
              color: "#fff",
              padding: "0.85rem 2rem",
              fontSize: "0.82rem",
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              textDecoration: "none",
              fontWeight: 400,
              transition: "border-color 0.2s, color 0.2s",
              display: "inline-block",
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "#fff"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.4)"; }}
          >
            Ver Servicios
          </a>
        </div>
      </motion.div>

      {/* Bottom fade */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: "120px",
          background: "linear-gradient(transparent, #0D0D0D)",
          pointerEvents: "none",
        }}
      />
    </section>
  );
}
