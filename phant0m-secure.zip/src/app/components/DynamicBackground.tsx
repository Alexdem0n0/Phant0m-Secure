import { useEffect, useRef } from "react";

const STYLE_ID = "phant0m-bg-keyframes";

function injectKeyframes() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = `
    @keyframes orbDrift1 {
      0%   { transform: translate(0px,   0px)   scale(1);    }
      33%  { transform: translate(-60px, 80px)  scale(1.08); }
      66%  { transform: translate(40px,  -40px) scale(0.95); }
      100% { transform: translate(0px,   0px)   scale(1);    }
    }
    @keyframes orbDrift2 {
      0%   { transform: translate(0px,   0px)   scale(1);    }
      40%  { transform: translate(80px,  -60px) scale(1.1);  }
      75%  { transform: translate(-30px, 50px)  scale(0.92); }
      100% { transform: translate(0px,   0px)   scale(1);    }
    }
    @keyframes orbDrift3 {
      0%   { transform: translate(0px,  0px)   scale(1);    }
      50%  { transform: translate(-50px,70px)  scale(1.06); }
      100% { transform: translate(0px,  0px)   scale(1);    }
    }
    @keyframes gridFade {
      0%,100% { opacity: 0.6; }
      50%     { opacity: 1;   }
    }
  `;
  document.head.appendChild(style);
}

export function DynamicBackground() {
  const orb1 = useRef<HTMLDivElement>(null);
  const orb2 = useRef<HTMLDivElement>(null);
  const orb3 = useRef<HTMLDivElement>(null);

  useEffect(() => {
    injectKeyframes();

    let rafId: number;
    let currentScroll = window.scrollY;
    let targetScroll = currentScroll;

    const onScroll = () => { targetScroll = window.scrollY; };

    const tick = () => {
      // Smooth lerp so parallax feels fluid
      currentScroll += (targetScroll - currentScroll) * 0.06;

      if (orb1.current) {
        orb1.current.style.marginTop = `${currentScroll * 0.12}px`;
      }
      if (orb2.current) {
        orb2.current.style.marginTop = `${currentScroll * -0.07}px`;
      }
      if (orb3.current) {
        orb3.current.style.marginTop = `${currentScroll * 0.05}px`;
      }

      rafId = requestAnimationFrame(tick);
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    rafId = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(rafId);
    };
  }, []);

  return (
    <div
      aria-hidden="true"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 0,
        background: "#0D0D0D",
        overflow: "hidden",
        pointerEvents: "none",
      }}
    >
      {/* Full-page grid */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
          animation: "gridFade 12s ease-in-out infinite",
        }}
      />

      {/* Orb 1 — top right, drifts slowly */}
      <div
        ref={orb1}
        style={{
          position: "absolute",
          top: "5%",
          left: "55%",
          width: "700px",
          height: "700px",
          background:
            "radial-gradient(circle, rgba(255,255,255,0.055) 0%, rgba(255,255,255,0.01) 50%, transparent 70%)",
          animation: "orbDrift1 22s ease-in-out infinite",
          willChange: "margin-top",
        }}
      />

      {/* Orb 2 — mid left, counter-drifts */}
      <div
        ref={orb2}
        style={{
          position: "absolute",
          top: "40%",
          left: "-15%",
          width: "650px",
          height: "650px",
          background:
            "radial-gradient(circle, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.008) 50%, transparent 70%)",
          animation: "orbDrift2 28s ease-in-out infinite",
          willChange: "margin-top",
        }}
      />

      {/* Orb 3 — bottom right, slow pulse */}
      <div
        ref={orb3}
        style={{
          position: "absolute",
          top: "72%",
          left: "60%",
          width: "550px",
          height: "550px",
          background:
            "radial-gradient(circle, rgba(255,255,255,0.035) 0%, transparent 65%)",
          animation: "orbDrift3 34s ease-in-out infinite",
          willChange: "margin-top",
        }}
      />

      {/* Subtle vignette to keep edges dark */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(ellipse at 50% 50%, transparent 40%, rgba(0,0,0,0.55) 100%)",
        }}
      />
    </div>
  );
}
