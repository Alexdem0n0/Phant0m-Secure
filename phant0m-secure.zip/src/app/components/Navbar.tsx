import { Link } from "react-router";
import { GhostLogo } from "./GhostLogo";

export function Navbar() {
  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-8 py-5"
      style={{
        background: "rgba(13,13,13,0.85)",
        backdropFilter: "blur(12px)",
        borderBottom: "1px solid rgba(255,255,255,0.05)",
      }}
    >
      <Link to="/" style={{ display: "flex", alignItems: "center", gap: "0.75rem", textDecoration: "none" }}>
        <GhostLogo size={32} />
        <span style={{ color: "#fff", letterSpacing: "0.12em", fontSize: "1rem", fontWeight: 600 }}>
          PHANT<span style={{ color: "#888" }}>0</span>M SECURE
        </span>
      </Link>

      <div className="hidden md:flex items-center gap-8">
        {[
          { label: "Servicios", href: "/#servicios" },
          { label: "Alcance", href: "/#alcance" },
          { label: "Blog", href: "/#blog" },
          { label: "FAQ", href: "/#faq" },
          { label: "Contacto", href: "/#contacto" },
          { label: "Sobre Mí", href: "/sobre-mi" },
        ].map((item) => (
          <a
            key={item.label}
            href={item.href}
            style={{
              color: "#aaa",
              fontSize: "0.82rem",
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              textDecoration: "none",
              transition: "color 0.2s",
            }}
            onMouseEnter={e => (e.currentTarget.style.color = "#fff")}
            onMouseLeave={e => (e.currentTarget.style.color = "#aaa")}
          >
            {item.label}
          </a>
        ))}
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
        <Link
          to="/signin"
          style={{
            color: "#aaa",
            fontSize: "0.82rem",
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            textDecoration: "none",
            fontWeight: 400,
            transition: "color 0.2s",
          }}
          onMouseEnter={e => (e.currentTarget.style.color = "#fff")}
          onMouseLeave={e => (e.currentTarget.style.color = "#aaa")}
        >
          Iniciar Sesión
        </Link>
        <Link
          to="/signup"
          style={{
            background: "#fff",
            color: "#000",
            padding: "0.45rem 1.2rem",
            fontSize: "0.78rem",
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            textDecoration: "none",
            fontWeight: 600,
            transition: "background 0.2s",
            display: "inline-block",
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#e0e0e0"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#fff"; }}
        >
          Registrarse
        </Link>
      </div>
    </nav>
  );
}
