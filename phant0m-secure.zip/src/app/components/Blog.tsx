import { Link } from "react-router";
import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { blogPosts } from "../data/blogPosts";

export function Blog() {
  return (
    <section id="blog" style={{ background: "rgba(13,13,13,0.78)", padding: "6rem 2rem" }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "4rem", flexWrap: "wrap", gap: "1rem" }}
        >
          <div>
            <p style={{ color: "#444", fontSize: "0.72rem", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: "1rem" }}>
              Conocimiento
            </p>
            <h2 style={{ color: "#fff", fontSize: "clamp(1.6rem, 4vw, 3rem)", fontWeight: 300, lineHeight: 1.2 }}>
              Inteligencia para la
              <span style={{ color: "#555" }}> Prevención Corporativa</span>
            </h2>
          </div>
          <Link
            to="/blog"
            style={{
              color: "#555",
              fontSize: "0.75rem",
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              textDecoration: "none",
              display: "flex",
              alignItems: "center",
              gap: "0.35rem",
              transition: "color 0.2s",
            }}
            onMouseEnter={e => { e.currentTarget.style.color = "#fff"; }}
            onMouseLeave={e => { e.currentTarget.style.color = "#555"; }}
          >
            Ver todos los artículos <ArrowUpRight size={13} />
          </Link>
        </motion.div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "1px", background: "rgba(255,255,255,0.04)" }}>
          {blogPosts.map((post, i) => (
            <motion.div
              key={post.slug}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.12 }}
            >
              <Link to={`/blog/${post.slug}`} style={{ textDecoration: "none", display: "block", height: "100%" }}>
                <div
                  style={{
                    background: "rgba(8,8,8,0.7)",
                    padding: "2.5rem",
                    cursor: "pointer",
                    display: "flex",
                    flexDirection: "column",
                    gap: "1rem",
                    height: "100%",
                    boxSizing: "border-box",
                    transition: "background 0.3s",
                  }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(20,20,20,0.9)"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(8,8,8,0.7)"; }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <span style={{ color: "#222", fontSize: "0.65rem", letterSpacing: "0.2em" }}>{post.number}</span>
                    <span style={{ color: "#333", fontSize: "0.65rem", letterSpacing: "0.12em", textTransform: "uppercase" }}>{post.category}</span>
                  </div>

                  <h3 style={{ color: "#fff", fontSize: "1rem", fontWeight: 400, lineHeight: 1.5, flex: 1 }}>{post.title}</h3>

                  <p style={{ color: "#555", fontSize: "0.82rem", lineHeight: 1.7 }}>{post.summary}</p>

                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: "1rem", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
                    <span style={{ color: "#333", fontSize: "0.72rem" }}>{post.readTime}</span>
                    <ArrowUpRight size={14} color="#444" />
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
