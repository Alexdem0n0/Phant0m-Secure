export function Watermark() {
  return (
    <div
      style={{
        position: "fixed",
        bottom: "0.75rem",
        left: "0.9rem",
        zIndex: 9999,
        color: "rgba(255,255,255,0.35)",
        fontSize: "0.7rem",
        letterSpacing: "0.08em",
        fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
        pointerEvents: "none",
        userSelect: "none",
      }}
    >
      Alex__dem0n
    </div>
  );
}
