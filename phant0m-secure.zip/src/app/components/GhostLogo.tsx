export function GhostLogo({ size = 40 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={Math.round(size * 1.2)}
      viewBox="0 0 40 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Body — original v1 silhouette */}
      <path
        d="M20 2C10.059 2 2 10.059 2 20V44L7 39L12 44L17 39L20 42L23 39L28 44L33 39L38 44V20C38 10.059 29.941 2 20 2Z"
        fill="white"
      />
      {/* Eyes */}
      <circle cx="14" cy="22" r="3" fill="#0D0D0D" />
      <circle cx="26" cy="22" r="3" fill="#0D0D0D" />
    </svg>
  );
}
