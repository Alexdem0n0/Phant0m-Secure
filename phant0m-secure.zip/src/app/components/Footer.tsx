import { GhostLogo } from "./GhostLogo";

export function Footer() {
  return (
    <footer style={{ background: "rgba(4,4,4,0.92)", padding: "3rem 2rem 2rem", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "2rem", marginBottom: "3rem" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", marginBottom: "1rem" }}>
              <GhostLogo size={24} />
              <span style={{ color: "#fff", fontSize: "0.85rem", letterSpacing: "0.12em" }}>
                PHANT<span style={{ color: "#555" }}>0</span>M SECURE
              </span>
            </div>
            <p style={{ color: "#333", fontSize: "0.78rem", lineHeight: 1.8 }}>
              Ciberseguridad estratégica para el sector
              <br />comercial y educativo privado.
              <br />Caracas, Venezuela.
            </p>
          </div>

          <div>
            <p style={{ color: "#555", fontSize: "0.65rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "1rem" }}>Servicios</p>
            {["Consultoría de Vulnerabilidades", "Respaldos Híbridos", "Seguridad de Redes", "Monitoreo EDR 24/7"].map(s => (
              <p key={s} style={{ color: "#333", fontSize: "0.78rem", marginBottom: "0.5rem" }}>{s}</p>
            ))}
          </div>

          <div>
            <p style={{ color: "#555", fontSize: "0.65rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "1rem" }}>Legal</p>
            {[
              "Política de Privacidad",
              "Términos y Condiciones",
              "Ley de Delitos Informáticos (VE)",
            ].map(l => (
              <p key={l} style={{ color: "#333", fontSize: "0.78rem", marginBottom: "0.5rem", cursor: "pointer" }}
                onMouseEnter={e => { e.currentTarget.style.color = "#666"; }}
                onMouseLeave={e => { e.currentTarget.style.color = "#333"; }}
              >{l}</p>
            ))}
          </div>

          <div>
            <p style={{ color: "#555", fontSize: "0.65rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "1rem" }}>Contacto</p>
            <p style={{ color: "#333", fontSize: "0.78rem", marginBottom: "0.5rem" }}>contacto@phant0msecure.com</p>
            <p style={{ color: "#333", fontSize: "0.78rem", marginBottom: "1.5rem" }}>Caracas, Venezuela</p>
            <div style={{ display: "flex", gap: "1rem" }}>
              {["LinkedIn", "X / Twitter"].map(s => (
                <span
                  key={s}
                  style={{ color: "#333", fontSize: "0.72rem", cursor: "pointer", transition: "color 0.2s" }}
                  onMouseEnter={e => { e.currentTarget.style.color = "#fff"; }}
                  onMouseLeave={e => { e.currentTarget.style.color = "#333"; }}
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div style={{ borderTop: "1px solid rgba(255,255,255,0.04)", paddingTop: "1.5rem", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "1rem" }}>
          <p style={{ color: "#222", fontSize: "0.72rem" }}>
            © 2026 Phant0m Secure. Todos los derechos reservados.
          </p>
          <p style={{ color: "#222", fontSize: "0.72rem" }}>
            Regulado bajo la Ley Especial contra los Delitos Informáticos (LECDI) — Venezuela
          </p>
        </div>
      </div>
    </footer>
  );
}
