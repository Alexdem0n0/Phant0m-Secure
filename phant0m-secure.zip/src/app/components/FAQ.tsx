import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Plus, Minus } from "lucide-react";

const faqs = [
  {
    q: "¿Por qué elegir Phant0m Secure si somos un negocio pequeño?",
    a: "Porque los atacantes buscan objetivos desprotegidos. Adaptamos nuestros costos a la escala de su escuela o tienda, brindando el mismo nivel de blindaje que a una multinacional. El tamaño de su empresa no determina el valor de sus datos.",
  },
  {
    q: "¿Cómo manejan el concepto de 'Protección que no ves'?",
    a: "Trabajamos en segundo plano mediante herramientas automatizadas y monitoreo invisible que no interrumpe las actividades diarias de sus empleados, interviniendo únicamente de forma proactiva ante amenazas. Su equipo opera con normalidad; nosotros vigilamos sin interferir.",
  },
  {
    q: "¿Qué pasa si mis sistemas fallan físicamente en sitio?",
    a: "Contamos con protocolos de respaldo híbridos offline y soporte técnico físico local en Caracas para recuperar la continuidad del negocio en tiempo récord. La presencia local es nuestra ventaja diferencial frente a proveedores remotos.",
  },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section id="faq" style={{ background: "rgba(10,10,10,0.82)", padding: "6rem 2rem" }}>
      <div style={{ maxWidth: "800px", margin: "0 auto" }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          style={{ textAlign: "center", marginBottom: "4rem" }}
        >
          <p style={{ color: "#444", fontSize: "0.72rem", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: "1rem" }}>
            Preguntas Frecuentes
          </p>
          <h2 style={{ color: "#fff", fontSize: "clamp(1.6rem, 4vw, 3rem)", fontWeight: 300, lineHeight: 1.2 }}>
            Respuestas directas,
            <span style={{ color: "#555" }}> sin tecnicismos</span>
          </h2>
        </motion.div>

        <div style={{ display: "flex", flexDirection: "column", gap: "1px", background: "rgba(255,255,255,0.04)" }}>
          {faqs.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              style={{ background: "rgba(8,8,8,0.7)" }}
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                style={{
                  width: "100%",
                  padding: "1.75rem 2rem",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  gap: "1rem",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                <span style={{ color: "#fff", fontSize: "0.95rem", fontWeight: 400, lineHeight: 1.5 }}>{faq.q}</span>
                <span style={{ flexShrink: 0 }}>
                  {open === i ? <Minus size={16} color="#666" /> : <Plus size={16} color="#444" />}
                </span>
              </button>

              <AnimatePresence>
                {open === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    style={{ overflow: "hidden" }}
                  >
                    <p style={{ color: "#555", fontSize: "0.88rem", lineHeight: 1.85, padding: "0 2rem 1.75rem" }}>
                      {faq.a}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
