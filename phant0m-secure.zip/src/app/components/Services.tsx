import { motion } from "motion/react";
import { ShieldCheck, HardDrive, Network, Activity } from "lucide-react";

const services = [
  {
    icon: ShieldCheck,
    title: "Consultorías de Vulnerabilidades",
    tag: "Auditoría Profunda",
    desc: "Auditorías e inspección profunda de sistemas informáticos y administrativos. Identificamos vectores de ataque antes de que los atacantes lo hagan.",
    detail: ["Análisis de superficie de ataque", "Pruebas de penetración controladas", "Informe ejecutivo de riesgo", "Plan de remediación priorizado"],
  },
  {
    icon: HardDrive,
    title: "Respaldos Híbridos Automatizados",
    tag: "Continuidad Operativa",
    desc: "Almacenamiento local automatizado en discos físicos de alta capacidad combinado con replicación cifrada en la nube para resistir incidentes de conectividad.",
    detail: ["Backup local NAS de alta capacidad", "Replicación cifrada en nube", "Resistencia a cortes eléctricos", "Recuperación en tiempo récord"],
  },
  {
    icon: Network,
    title: "Seguridad de Redes Complejas",
    tag: "Infraestructura VPN",
    desc: "Implementación de redes VPN corporativas para un acceso remoto encriptado y seguro. Su equipo conectado, su red blindada.",
    detail: ["VPN corporativa cifrada", "Segmentación de red", "Control de acceso por rol", "Auditoría de tráfico en tiempo real"],
  },
  {
    icon: Activity,
    title: "Monitoreo Remoto EDR 24/7",
    tag: "Detección y Respuesta",
    desc: "Protocolos de detección y respuesta inmediata ante cualquier comportamiento inusual en la red. Vigilancia continua, intervención instantánea.",
    detail: ["Detección de anomalías en tiempo real", "Respuesta automática ante amenazas", "Panel de visibilidad centralizado", "Alertas a equipo de seguridad"],
  },
];

export function Services() {
  return (
    <section id="servicios" style={{ background: "rgba(13,13,13,0.78)", padding: "6rem 2rem" }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          style={{ marginBottom: "4rem" }}
        >
          <p style={{ color: "#444", fontSize: "0.72rem", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: "1rem" }}>
            Portafolio de Servicios
          </p>
          <h2
            style={{
              color: "#fff",
              fontSize: "clamp(1.6rem, 4vw, 3rem)",
              fontWeight: 300,
              lineHeight: 1.2,
              maxWidth: "600px",
            }}
          >
            Soluciones modulares para
            <span style={{ color: "#555" }}> cada vector de amenaza</span>
          </h2>
        </motion.div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: "1px", background: "rgba(255,255,255,0.04)" }}>
          {services.map((service, i) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                style={{
                  background: "rgba(8,8,8,0.7)",
                  padding: "2.5rem",
                  cursor: "default",
                  transition: "background 0.3s",
                  position: "relative",
                  overflow: "hidden",
                }}
                whileHover={{ backgroundColor: "#141414" }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" }}>
                  <Icon size={20} color="#fff" strokeWidth={1} />
                  <span style={{ color: "#333", fontSize: "0.65rem", letterSpacing: "0.15em", textTransform: "uppercase" }}>{service.tag}</span>
                </div>
                <h3 style={{ color: "#fff", fontSize: "1rem", fontWeight: 400, marginBottom: "1rem", lineHeight: 1.4 }}>{service.title}</h3>
                <p style={{ color: "#555", fontSize: "0.84rem", lineHeight: 1.8, marginBottom: "1.5rem" }}>{service.desc}</p>
                <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
                  {service.detail.map((d) => (
                    <li key={d} style={{ color: "#444", fontSize: "0.78rem", padding: "0.3rem 0", display: "flex", alignItems: "center", gap: "0.5rem" }}>
                      <span style={{ width: "4px", height: "4px", background: "#444", borderRadius: "50%", flexShrink: 0 }} />
                      {d}
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
