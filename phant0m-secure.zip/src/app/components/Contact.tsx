import { useState } from "react";
import { motion } from "motion/react";
import { Send } from "lucide-react";

export function Contact() {
  const [form, setForm] = useState({
    empresa: "",
    tipo: "",
    email: "",
    mensaje: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handle = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const inputStyle: React.CSSProperties = {
    width: "100%",
    background: "transparent",
    border: "none",
    borderBottom: "1px solid rgba(255,255,255,0.12)",
    color: "#fff",
    padding: "0.75rem 0",
    fontSize: "0.9rem",
    outline: "none",
    fontFamily: "inherit",
    transition: "border-color 0.2s",
    boxSizing: "border-box",
  };

  const labelStyle: React.CSSProperties = {
    color: "#444",
    fontSize: "0.7rem",
    letterSpacing: "0.15em",
    textTransform: "uppercase",
    display: "block",
    marginBottom: "0.25rem",
  };

  return (
    <section id="contacto" style={{ background: "rgba(13,13,13,0.78)", padding: "6rem 2rem" }}>
      <div style={{ maxWidth: "700px", margin: "0 auto" }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          style={{ textAlign: "center", marginBottom: "3.5rem" }}
        >
          <p style={{ color: "#444", fontSize: "0.72rem", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: "1rem" }}>
            Contacto
          </p>
          <h2 style={{ color: "#fff", fontSize: "clamp(1.6rem, 4vw, 3rem)", fontWeight: 300, lineHeight: 1.2 }}>
            Asegure el Patrimonio de
            <span style={{ color: "#555" }}> su Organización Hoy</span>
          </h2>
        </motion.div>

        {submitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            style={{
              textAlign: "center",
              padding: "4rem",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <p style={{ color: "#fff", fontSize: "1.1rem", marginBottom: "0.75rem" }}>Solicitud recibida.</p>
            <p style={{ color: "#555", fontSize: "0.88rem" }}>
              Su diagnóstico de seguridad será agendado en menos de 2 horas.
            </p>
          </motion.div>
        ) : (
          <motion.form
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            onSubmit={submit}
            style={{ display: "flex", flexDirection: "column", gap: "2rem" }}
          >
            <div>
              <label style={labelStyle}>Nombre de la Empresa / Institución</label>
              <input
                name="empresa"
                value={form.empresa}
                onChange={handle}
                required
                placeholder="Ej. Colegio San Pedro / Distribuidora Delta"
                style={inputStyle}
                onFocus={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.5)"; }}
                onBlur={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.12)"; }}
              />
            </div>

            <div>
              <label style={labelStyle}>Tipo de Negocio</label>
              <select
                name="tipo"
                value={form.tipo}
                onChange={handle}
                required
                style={{ ...inputStyle, cursor: "pointer" }}
                onFocus={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.5)"; }}
                onBlur={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.12)"; }}
              >
                <option value="" style={{ background: "#111" }}>Seleccione una categoría</option>
                <option value="colegio" style={{ background: "#111" }}>Colegio / Institución Educativa</option>
                <option value="tienda" style={{ background: "#111" }}>Tienda / Retail</option>
                <option value="pyme" style={{ background: "#111" }}>PYME / Empresa Mediana</option>
                <option value="corporacion" style={{ background: "#111" }}>Corporación / Gran Empresa</option>
                <option value="otro" style={{ background: "#111" }}>Otro</option>
              </select>
            </div>

            <div>
              <label style={labelStyle}>Correo Electrónico de Contacto</label>
              <input
                name="email"
                type="email"
                value={form.email}
                onChange={handle}
                required
                placeholder="contacto@suorganizacion.com"
                style={inputStyle}
                onFocus={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.5)"; }}
                onBlur={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.12)"; }}
              />
            </div>

            <div>
              <label style={labelStyle}>Mensaje o Requerimiento</label>
              <textarea
                name="mensaje"
                value={form.mensaje}
                onChange={handle}
                rows={4}
                placeholder="Describa brevemente su situación actual o las áreas que le preocupan..."
                style={{ ...inputStyle, resize: "none" }}
                onFocus={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.5)"; }}
                onBlur={e => { e.currentTarget.style.borderBottomColor = "rgba(255,255,255,0.12)"; }}
              />
            </div>

            <button
              type="submit"
              style={{
                background: "#fff",
                color: "#000",
                border: "none",
                padding: "1rem 2rem",
                fontSize: "0.82rem",
                letterSpacing: "0.1em",
                textTransform: "uppercase",
                fontWeight: 600,
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "0.6rem",
                transition: "background 0.2s",
                fontFamily: "inherit",
              }}
              onMouseEnter={e => { e.currentTarget.style.background = "#ddd"; }}
              onMouseLeave={e => { e.currentTarget.style.background = "#fff"; }}
            >
              <Send size={14} />
              Solicitar Diagnóstico de Seguridad
            </button>

            <p style={{ color: "#333", fontSize: "0.72rem", textAlign: "center", lineHeight: 1.7 }}>
              [Este formulario se encuentra integrado automáticamente a un Spreadsheet en la nube
              para procesar y agendar su diagnóstico de seguridad en menos de 2 horas]
            </p>
          </motion.form>
        )}
      </div>
    </section>
  );
}
