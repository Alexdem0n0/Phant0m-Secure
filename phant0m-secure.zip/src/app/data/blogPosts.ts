export type BlogPost = {
  slug: string;
  number: string;
  category: string;
  title: string;
  summary: string;
  readTime: string;
  date: string;
  author: string;
  sections: {
    heading?: string;
    body: string;
  }[];
  tags: string[];
};

export const blogPosts: BlogPost[] = [
  {
    slug: "el-factor-humano",
    number: "01",
    category: "Factor Humano",
    title: "El factor humano: Cómo evitar que la salida de un empleado comprometa el histórico de tu empresa.",
    summary: "Un colaborador saliente con acceso no revocado puede borrar años de datos en minutos. Descubra los protocolos que lo previenen.",
    readTime: "5 min lectura",
    date: "3 de junio, 2026",
    author: "Equipo Phant0m Secure",
    tags: ["Factor Humano", "Acceso", "Protocolos", "Datos"],
    sections: [
      {
        body: "En la ciberseguridad corporativa, el mayor riesgo no siempre proviene de un hacker externo vestido de negro tecleando desde algún sótano. La estadística es implacable: más del 60% de los incidentes de seguridad tienen origen interno. Y el escenario más común es también el más silencioso: un empleado que se va."
      },
      {
        heading: "El momento más vulnerable de una empresa",
        body: "Cuando un colaborador abandona la organización, ya sea por renuncia voluntaria, despido o reestructuración, existe una ventana de tiempo crítica. Durante ese período, si los accesos no han sido revocados de forma inmediata y sistemática, esa persona retiene la capacidad de leer, copiar, modificar o eliminar información sensible. Correos corporativos, bases de datos de clientes, historial financiero, documentos estratégicos: todo queda expuesto.\n\nEn el contexto venezolano, donde la rotación de personal es elevada y muchas empresas aún operan con sistemas de control de acceso informal, esta vulnerabilidad es especialmente pronunciada."
      },
      {
        heading: "El perfil del riesgo: no solo los malintencionados",
        body: "Es un error asumir que solo los empleados con rencor representan un peligro. Existen tres arquetipos de riesgo igualmente peligrosos:\n\n1. El colaborador que no sabe que sigue teniendo acceso. Siguió usando las cuentas compartidas por costumbre, sin intención maliciosa, pero comprometiendo datos regulados.\n\n2. El colaborador oportunista. Al darse cuenta de que nadie revocó sus credenciales, decide llevarse contactos de clientes, propuestas comerciales o código fuente propietario.\n\n3. El colaborador agraviado. El escenario más crítico: alguien con motivación activa para causar daño. Desde eliminar backups hasta filtrar información a la competencia."
      },
      {
        heading: "El protocolo de desvinculación segura",
        body: "La solución no es desconfiar de cada persona que trabaja con usted. Es implementar un proceso estructurado que funcione de forma automática e independiente de la relación personal que tenga con el colaborador. Un protocolo de desvinculación segura debe contemplar:\n\nRevocación inmediata de accesos: En el mismo momento en que se formaliza la desvinculación, no al día siguiente. Esto incluye correo corporativo, sistemas internos, VPN, plataformas en la nube, herramientas de gestión y cualquier cuenta compartida.\n\nAuditoría de actividad pre-salida: Revisar los registros de acceso de las últimas semanas para detectar comportamientos inusuales: descargas masivas, acceso a carpetas fuera del rol habitual, envíos externos de archivos.\n\nCambio de credenciales compartidas: Contraseñas de routers, cámaras, herramientas colaborativas y cualquier cuenta de equipo deben ser rotadas automáticamente.\n\nInventario de activos digitales: Asegurarse de que los dispositivos corporativos hayan sido devueltos y sus discos sanitizados correctamente."
      },
      {
        heading: "Los datos pertenecen a la institución, no al individuo",
        body: "El principio que guía toda nuestra arquitectura de protección en Phant0m Secure es este: la información generada dentro de la empresa durante el ejercicio de funciones laborales es un activo institucional. No es propiedad del empleado que la produjo.\n\nImplementar esta filosofía a nivel técnico significa separar las cuentas personales de las corporativas desde el primer día, centralizar la información en sistemas bajo control exclusivo de la empresa, y nunca depender de la buena voluntad de un individuo para acceder a recursos críticos.\n\nUna empresa que implementa correctamente estos principios puede desvincularse de un colaborador en cualquier momento, con cualquier nivel de conflicto, sin que eso signifique una crisis de seguridad."
      },
      {
        heading: "¿Por dónde empezar?",
        body: "Si usted gestiona una empresa sin un protocolo formal de desvinculación, el primer paso es un diagnóstico de accesos. Mapear quién tiene acceso a qué, con qué nivel de privilegio, y qué pasaría si esa persona dejara de trabajar mañana. Ese ejercicio suele revelar vulnerabilidades sorprendentes incluso en organizaciones que se consideran bien organizadas.\n\nEn Phant0m Secure realizamos ese diagnóstico como parte de nuestra consultoría inicial, y en la mayoría de los casos encontramos accesos fantasma: cuentas activas de personas que ya no forman parte de la empresa. Cada una de esas cuentas es una puerta abierta."
      }
    ]
  },
  {
    slug: "redundancia-hibrida",
    number: "02",
    category: "Infraestructura",
    title: "Redundancia Híbrida: Estrategias para proteger tus servidores ante cortes de energía en Caracas.",
    summary: "La inestabilidad eléctrica es una realidad operativa. Una arquitectura de respaldo híbrido convierte ese riesgo en una ventaja estratégica.",
    readTime: "7 min lectura",
    date: "1 de junio, 2026",
    author: "Equipo Phant0m Secure",
    tags: ["Infraestructura", "Backup", "Energía", "Caracas", "Resiliencia"],
    sections: [
      {
        body: "Cualquier gerente de TI en Caracas conoce el sonido del UPS activándose. Es un sonido que se ha vuelto tan cotidiano como el tráfico de la autopista. La inestabilidad del servicio eléctrico en Venezuela no es un evento excepcional; es una condición operativa permanente que toda empresa debe incorporar en su arquitectura de seguridad."
      },
      {
        heading: "El verdadero costo de un corte no planificado",
        body: "Un corte de energía que dura tres segundos puede causar daños que tardan días en resolverse. Los escenarios de falla más comunes que documentamos en nuestros diagnósticos incluyen:\n\nCorrupción de bases de datos activas: Un servidor que pierde energía mientras escribe en disco puede dejar tablas en estado inconsistente, lo que a veces requiere restauración completa desde el último backup válido.\n\nFalla de hardware por voltaje inestable: Los picos y caídas de tensión degradan componentes con el tiempo. Los discos duros y fuentes de poder son los primeros en ceder.\n\nPérdida de caché no confirmada: Muchos sistemas mantienen datos en memoria RAM antes de escribirlos en disco. Un corte abrupto significa que esos datos desaparecen permanentemente.\n\nInterrupción de procesos críticos: Transacciones financieras, sincronizaciones de inventario, respaldos en curso: cualquier proceso que estuviera activo en el momento del corte queda en estado desconocido."
      },
      {
        heading: "El modelo de redundancia híbrida",
        body: "La respuesta a este problema no es simplemente conectar un UPS de mayor capacidad y esperar lo mejor. La redundancia real requiere capas. El modelo que implementamos en Phant0m Secure opera en tres niveles simultáneos:\n\nNivel 1 — Protección eléctrica activa: UPS de doble conversión para los servidores críticos, con autonomía calculada para cubrir los cortes de duración promedio del área. Generador de respaldo para instalaciones que no pueden permitirse ninguna interrupción.\n\nNivel 2 — Respaldo local automatizado: NAS (Network Attached Storage) de alta capacidad con RAID configurado para tolerancia a fallas. Las copias de seguridad se ejecutan según un calendario programado, con verificación automática de integridad. Este sistema opera de forma completamente offline si es necesario, lo que significa que un corte de conectividad a Internet no afecta la disponibilidad de los datos.\n\nNivel 3 — Replicación cifrada en la nube: Una copia adicional de los datos críticos se sincroniza cifrada hacia servidores en la nube. Esto protege contra el escenario más extremo: daño físico a la infraestructura local, ya sea por falla eléctrica severa, robo de equipos o desastres."
      },
      {
        heading: "Por qué el backup local sigue siendo indispensable en Venezuela",
        body: "En contextos de alta disponibilidad de internet, muchas empresas migraron completamente sus backups a la nube y eliminaron el almacenamiento local. En Venezuela, esa estrategia es un error. La conectividad a internet es tan variable como el suministro eléctrico. Durante un corte mayor que afecte simultáneamente la energía y las comunicaciones, una empresa que depende exclusivamente de la nube queda completamente ciega.\n\nEl almacenamiento local garantiza acceso a los datos críticos independientemente del estado de la red. Un médico puede seguir accediendo al historial de su paciente. Una tienda puede seguir procesando ventas con su base de datos local. Una escuela puede continuar con sus registros académicos. La nube complementa; no reemplaza."
      },
      {
        heading: "Automatización: el elemento que lo cambia todo",
        body: "El talón de Aquiles de los sistemas de backup en pequeñas y medianas empresas no es tecnológico: es humano. Los backups manuales se olvidan, se posponen o directamente dejan de ejecutarse. La automatización elimina esa variable.\n\nCuando configuramos un sistema de redundancia híbrida, el proceso completo ocurre sin intervención humana: los backups se ejecutan en horarios programados, se verifica su integridad automáticamente, se rotan según políticas de retención definidas, y se genera un reporte de estado que puede revisarse cada mañana en dos minutos.\n\nSi algo falla en el proceso, el sistema alerta antes de que se convierta en un problema. Usted sabe que sus datos están protegidos sin tener que pensar en ello cada día."
      },
      {
        heading: "El tiempo de recuperación es la métrica que importa",
        body: "En seguridad operativa, el indicador clave no es cuánto tiempo tarda el backup en ejecutarse, sino cuánto tiempo tarda la empresa en volver a operar después de un incidente. Este valor se conoce como RTO (Recovery Time Objective) y definirlo explícitamente es parte de todo proyecto que implementamos.\n\nPara una tienda de retail: volver a procesar ventas en menos de 30 minutos. Para un colegio: tener acceso a registros de estudiantes antes del inicio de clases. Para una empresa de servicios: retomar operaciones antes de que el cliente note la interrupción.\n\nCada arquitectura de redundancia que diseñamos tiene como objetivo un RTO específico. No backups por tenerlos: backups que garantizan continuidad operativa medible."
      }
    ]
  },
  {
    slug: "ciberseguridad-pequenos-negocios",
    number: "03",
    category: "Pequeños Negocios",
    title: "Ciberseguridad en Pequeños Negocios: Por qué las escuelas y tiendas son los objetivos más vulnerables.",
    summary: "Los atacantes priorizan objetivos desprotegidos. Conozca por qué su institución educativa o comercio es más valioso para ellos de lo que imagina.",
    readTime: "6 min lectura",
    date: "28 de mayo, 2026",
    author: "Equipo Phant0m Secure",
    tags: ["Pequeños Negocios", "Educación", "Retail", "Amenazas", "Prevención"],
    sections: [
      {
        body: "Existe un mito persistente en el mundo empresarial que suena razonable pero es profundamente peligroso: 'somos muy pequeños para que alguien nos ataque'. Esta creencia lleva a escuelas, tiendas y pequeñas empresas a operar sin ningún mecanismo de protección, bajo la convicción de que los cibercriminales solo se interesan por los grandes corporativos. La realidad funciona exactamente al revés."
      },
      {
        heading: "Por qué el tamaño pequeño es una ventaja para el atacante",
        body: "Los atacantes modernos operan con lógica de eficiencia. No invierten semanas tratando de penetrar la infraestructura de seguridad de un banco cuando pueden comprometer veinte colegios en el mismo tiempo con herramientas automatizadas.\n\nLos pequeños negocios son objetivos preferidos por razones muy concretas:\n\nSin equipo de seguridad dedicado: No hay un profesional monitoreando la red. Un ataque puede estar activo durante semanas sin que nadie lo note.\n\nSoftware desactualizado: Las actualizaciones de seguridad se posponen indefinidamente porque 'todo funciona'. Cada parche que no se instala es una vulnerabilidad conocida y pública esperando ser explotada.\n\nContraseñas débiles o compartidas: Un estudio de 2025 encontró que el 43% de las pequeñas empresas en Latinoamérica utilizan la misma contraseña para múltiples sistemas críticos.\n\nSin backups verificados: Muchos tienen alguna forma de backup, pero nunca han verificado que realmente funciona. Cuando lo necesitan, descubren que el archivo está corrupto o incompleto."
      },
      {
        heading: "El caso específico de las instituciones educativas",
        body: "Los colegios e institutos educativos merecen un análisis particular porque concentran una combinación de datos que los hace especialmente valiosos: información personal de menores de edad, datos financieros de las familias, historial académico protegido por regulaciones de privacidad, y en muchos casos, información de salud de los estudiantes.\n\nEn Venezuela, la mayoría de los colegios privados digitalizaron sus procesos administrativos en los últimos años, pero sin acompañar esa digitalización con las medidas de seguridad correspondientes. El resultado es que manejan volúmenes crecientes de datos sensibles en infraestructuras que no fueron diseñadas para protegerlos.\n\nUn ataque de ransomware a un colegio tiene consecuencias que van más allá del económico: puede comprometer años de historial académico de cientos de estudiantes, exponer información privada de familias, y en el peor escenario, forzar el cierre temporal de la institución durante el período de recuperación."
      },
      {
        heading: "El caso específico del comercio minorista",
        body: "Las tiendas y negocios de retail procesan algo que para un cibercriminal tiene valor inmediato: datos de pago. Incluso en un contexto de alta transaccionalidad en efectivo como el venezolano, los sistemas de punto de venta, las cuentas de Pago Móvil, y las plataformas de e-commerce generan información financiera que puede ser comprometida.\n\nAdemás, las tiendas suelen tener una superficie de ataque más amplia de lo que sus dueños perciben: terminales de pago conectadas a la red local, cámaras de seguridad con acceso remoto configurado de fábrica, sistemas de inventario accesibles desde el mismo Wi-Fi que usan los clientes, y en muchos casos, computadoras que mezclan uso administrativo con uso personal.\n\nCada uno de esos elementos es un vector de entrada potencial."
      },
      {
        heading: "Los tres ataques más comunes en pequeños negocios",
        body: "Phishing dirigido al personal administrativo: Un correo que parece venir de un proveedor conocido, del banco o de un organismo oficial. Un clic en el enlace compromete las credenciales del sistema. Este es el vector de entrada número uno en incidentes que documentamos.\n\nRansomware automatizado: Software malicioso que cifra todos los archivos accesibles en la red y exige pago para recuperarlos. Sin un backup actualizado y offline, la única salida es pagar o perder todo.\n\nAcceso no autorizado por credenciales débiles o reutilizadas: Si la contraseña del sistema de administración es la misma que la del correo personal del gerente, y ese correo fue comprometido en alguna filtración pública, el acceso al sistema está a un paso."
      },
      {
        heading: "Protección adaptada a la realidad del negocio pequeño",
        body: "La buena noticia es que proteger un negocio pequeño no requiere el presupuesto de una corporación. Requiere un enfoque correcto y proporcional al perfil de riesgo real.\n\nEn Phant0m Secure trabajamos con una premisa clara: la seguridad debe ser accesible para cualquier organización que la tome en serio, independientemente de su tamaño. Nuestros planes para pequeños negocios y colegios son modulares: comenzamos por los elementos de mayor impacto y menor costo (gestión de accesos, backup automático verificado, capacitación básica del personal) y escalamos según las necesidades específicas de cada cliente.\n\nEl costo de implementar seguridad básica es siempre menor que el costo de recuperarse de un incidente. Y en el caso de los datos de estudiantes o clientes, algunas pérdidas simplemente no tienen recuperación posible."
      }
    ]
  }
];

export function getPostBySlug(slug: string): BlogPost | undefined {
  return blogPosts.find(p => p.slug === slug);
}
