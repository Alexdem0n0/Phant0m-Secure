# Phant0m Secure — Cómo desplegar (sin Git)

Este proyecto es una app React + Vite, EXACTAMENTE igual a la que tenías en
Figma (Landing, SignIn, SignUp, Dashboard, Blog), más:

- Página nueva "Sobre Mí" en /sobre-mi (con link a tu GitHub:
  https://github.com/Alexdem0n0), accesible desde el navbar.
- Watermark fijo "Alex__dem0n" en la esquina inferior izquierda, visible en
  TODAS las páginas.

## 1. Requisitos

Instala Node.js (versión 18 o superior) desde https://nodejs.org si no lo
tienes. Eso te da `node` y `npm`.

## 2. Instalar dependencias

Abre una terminal dentro de esta carpeta (donde está package.json) y corre:

    npm install

Esto puede tardar unos minutos la primera vez.

## 3. Probar localmente (opcional)

    npm run dev

Abre la URL que te muestre (normalmente http://localhost:5173) para ver la
página funcionando en tu navegador, exactamente igual que en Figma.

## 4. Generar la build de producción

    npm run build

Esto crea una carpeta `dist/` con TODOS los archivos finales (HTML, JS, CSS,
imágenes) listos para subir a internet. Esta carpeta es la que necesitas para
desplegar — no el código fuente.

## 5. Subir a Netlify SIN Git

1. Ve a https://app.netlify.com y crea una cuenta (gratis).
2. En el dashboard, busca la opción "Add new site" -> "Deploy manually" (o
   "Deploy without Git" / arrastra y suelta).
3. Arrastra la carpeta `dist/` completa (la que se generó en el paso 4) a la
   zona de drop de Netlify.
4. Netlify la sube y te da una URL pública al instante (algo como
   random-name-123.netlify.app). La página ya está en línea, accesible para
   cualquiera, sin que tengas que "activarla" cada vez.
5. (Opcional) En "Site settings" puedes cambiar el nombre del sitio o conectar
   un dominio propio.

Cada vez que quieras actualizar la página: repite los pasos 4 y 5 (build +
arrastrar la nueva carpeta dist/ a Netlify, hay un botón para reemplazar el
deploy). No necesitas Git para nada de esto.

## Notas sobre "Sobre Mí"

GitHub bloquea que su sitio se muestre dentro de un iframe en otras páginas
(por seguridad, ellos lo configuran así, no es algo que se pueda evitar desde
tu lado). Por eso la sección "Sobre Mí" incluye un botón grande que abre tu
perfil de GitHub (https://github.com/Alexdem0n0) en una pestaña nueva, y un
recuadro que intentará mostrar el perfil embebido — si no carga, mostrará un
mensaje con el link directo.
